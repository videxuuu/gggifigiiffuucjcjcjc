package com.videx.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Videx: envoltorio (WebView) de la web. Toda la lógica vive en el servidor (index.php).
 * La app solo busca el dominio que responda, lo abre y añade: pantalla completa, botón atrás,
 * compartir, enlaces externos fuera de la app y cambio automático de dominio si uno cae.
 */
public class MainActivity extends Activity {

    // ================= CONFIGURACIÓN =================
    // Dominios de Videx (el mismo index.php en todos). El primero que responda se usa.
    private static final String[] DOMAINS = {
            "videxhd.top", "videxhd.sbs", "videx.lol", "videxhd.biz.id", "videxhd.web.id"
    };
    private static final String START_PATH = "/";
    private static final String UA_SUFFIX = " VidexApp/1.0";
    private static final String PROBE_PATH = "/app.webmanifest"; // ligero; el sitio lo sirve con "Videx" dentro
    private static final String PROBE_MARK = "Videx";
    // =================================================

    private static final int BG = Color.parseColor("#07060C");
    private static final int ACCENT = Color.parseColor("#2A6FF0");
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    // navigator.share no existe en WebView: lo enlazamos al menú de compartir de Android
    private static final String SHARE_JS =
            "(function(){if(window.__vxShare)return;window.__vxShare=1;try{"
          + "navigator.share=function(d){d=d||{};window.VidexApp.share(String(d.title||''),String(d.text||''),String(d.url||''));return Promise.resolve();};"
          + "navigator.canShare=function(){return true;};}catch(e){}})();";

    private interface HostCb { void on(String host); }

    private FrameLayout root;
    private WebView web;
    private LinearLayout splash, errorBox;
    private TextView splashMsg, errorMsg;
    private Button retryBtn;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private SharedPreferences prefs;
    private Handler ui;
    private String ua = "";
    private String currentHost;
    private boolean resolving, pageFailed;
    private int switches = 0;

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ui = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences("videx", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        setupWebView();
        start(pathFromIntent(getIntent()));
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i.getData() != null && currentHost != null && !resolving) {
            exitFullscreen();
            pageFailed = false;
            web.loadUrl("https://" + currentHost + pathFromIntent(i));
        }
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        try { root.removeView(web); web.destroy(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && customView != null) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { exitFullscreen(); return; }
        if (errorBox.getVisibility() == View.VISIBLE) { finish(); return; }
        if (web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    // ---------------------------------------------------------------- interfaz

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Pantalla de carga
        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(BG);
        splash.setClickable(true);
        TextView logo = text("VIDEX", 34, Color.WHITE, true);
        logo.setLetterSpacing(0.18f);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        splashMsg = text("Buscando el mejor servidor…", 14, Color.parseColor("#9A98A6"), false);
        LinearLayout.LayoutParams lpPb = new LinearLayout.LayoutParams(dp(40), dp(40));
        lpPb.topMargin = dp(28);
        LinearLayout.LayoutParams lpMsg = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpMsg.topMargin = dp(16);
        splash.addView(logo);
        splash.addView(pb, lpPb);
        splash.addView(splashMsg, lpMsg);
        root.addView(splash, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Pantalla de error
        errorBox = new LinearLayout(this);
        errorBox.setOrientation(LinearLayout.VERTICAL);
        errorBox.setGravity(Gravity.CENTER);
        errorBox.setBackgroundColor(BG);
        errorBox.setPadding(dp(32), dp(32), dp(32), dp(32));
        errorBox.setClickable(true);
        errorBox.setVisibility(View.GONE);
        TextView ttl = text("No se pudo conectar", 20, Color.WHITE, true);
        errorMsg = text("", 14, Color.parseColor("#9A98A6"), false);
        retryBtn = new Button(this);
        retryBtn.setText("Reintentar");
        retryBtn.setAllCaps(false);
        retryBtn.setTextColor(Color.WHITE);
        retryBtn.setBackgroundColor(ACCENT);
        retryBtn.setPadding(dp(32), dp(10), dp(32), dp(10));
        retryBtn.setOnClickListener(v -> { switches = 0; start(currentPath()); });
        LinearLayout.LayoutParams lpE = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpE.topMargin = dp(12);
        LinearLayout.LayoutParams lpB = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpB.topMargin = dp(28);
        errorBox.addView(ttl);
        errorBox.addView(errorMsg, lpE);
        errorBox.addView(retryBtn, lpB);
        root.addView(errorBox, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
    }

    private void showSplash(String msg) {
        splashMsg.setText(msg);
        errorBox.setVisibility(View.GONE);
        splash.setVisibility(View.VISIBLE);
    }

    private void hideSplash() { splash.setVisibility(View.GONE); }

    private void showError(String msg) {
        errorMsg.setText(msg);
        splash.setVisibility(View.GONE);
        errorBox.setVisibility(View.VISIBLE);
        retryBtn.requestFocus();
    }

    // ---------------------------------------------------------------- WebView

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + UA_SUFFIX);
        ua = s.getUserAgentString();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true); // chat / embeds de otros dominios

        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "VidexApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
    }

    public final class Bridge {
        @JavascriptInterface
        public void share(final String title, final String text, final String url) {
            ui.post(() -> {
                String body = (text == null ? "" : text);
                if (url != null && url.length() > 0) body = body.length() > 0 ? body + "\n" + url : url;
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, body);
                if (title != null && title.length() > 0) i.putExtra(Intent.EXTRA_SUBJECT, title);
                try { startActivity(Intent.createChooser(i, null)); } catch (Exception ignored) {}
            });
        }
    }

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleUrl(r.getUrl());
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (pageFailed) return;
            switches = 0;
            try {
                if (url != null && isVidexHost(Uri.parse(url).getHost())) v.evaluateJavascript(SHARE_JS, null);
            } catch (Exception ignored) {}
            CookieManager.getInstance().flush();
            hideSplash();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (!r.isForMainFrame()) return;
            if (String.valueOf(e.getDescription()).contains("ERR_ABORTED")) return;
            onMainFrameFailed();
        }

        @Override
        public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse e) {
            if (!r.isForMainFrame()) return;
            int c = e.getStatusCode();
            if (c == 502 || c == 504 || (c >= 520 && c <= 530)) onMainFrameFailed();
        }

        @Override
        public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
            h.cancel();
            try {
                String host = Uri.parse(e.getUrl()).getHost();
                if (host != null && host.equals(currentHost)) onMainFrameFailed();
            } catch (Exception ignored) {}
        }
    }

    private final class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            if (p >= 70 && !pageFailed && errorBox.getVisibility() != View.VISIBLE) hideSplash();
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            root.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
            enterFullscreen();
        }

        @Override
        public void onHideCustomView() { exitFullscreen(); }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // sin el icono gris de "play"
        }
    }

    // ---------------------------------------------------------------- pantalla completa

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void setCutout(boolean shortEdges) {
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = shortEdges
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            getWindow().setAttributes(lp);
        }
    }

    private void enterFullscreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        setCutout(true);
        hideSystemBars();
    }

    private void exitFullscreen() {
        if (customView == null) return;
        View v = customView;
        WebChromeClient.CustomViewCallback cb = customCb;
        customView = null;
        customCb = null;
        root.removeView(v);
        if (cb != null) cb.onCustomViewHidden();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        setCutout(false);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ---------------------------------------------------------------- dominios y carga

    private boolean isVidexHost(String host) {
        if (host == null) return false;
        host = host.toLowerCase();
        for (String d : DOMAINS) if (host.equals(d) || host.endsWith("." + d)) return true;
        return false;
    }

    private boolean isKnown(String host) {
        for (String d : DOMAINS) if (d.equals(host)) return true;
        return false;
    }

    private String pathFromIntent(Intent i) {
        try {
            Uri d = i == null ? null : i.getData();
            if (d != null && isVidexHost(d.getHost())) {
                String p = d.getEncodedPath();
                if (p == null || p.isEmpty()) p = "/";
                String q = d.getEncodedQuery();
                return q == null ? p : p + "?" + q;
            }
        } catch (Exception ignored) {}
        return START_PATH;
    }

    private String currentPath() {
        try {
            String u = web.getUrl();
            if (u != null) {
                Uri x = Uri.parse(u);
                if (isVidexHost(x.getHost())) {
                    String p = x.getEncodedPath();
                    if (p == null || p.isEmpty()) p = "/";
                    String q = x.getEncodedQuery();
                    return q == null ? p : p + "?" + q;
                }
            }
        } catch (Exception ignored) {}
        return START_PATH;
    }

    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            return n != null && n.isConnected();
        } catch (Exception e) { return true; }
    }

    private void start(final String path) {
        if (resolving) return;
        showSplash("Buscando el mejor servidor…");
        findHost(null, host -> {
            if (host != null) { load(host, path); return; }
            if (online()) {
                // ninguna prueba respondió, pero hay red: intentamos igualmente (puede ser un desafío anti-bot)
                load(prefs.getString("host", DOMAINS[0]), path);
            } else {
                showError("Sin conexión a internet.\nRevisa tu red e inténtalo de nuevo.");
            }
        });
    }

    private void load(String host, String path) {
        currentHost = host;
        pageFailed = false;
        prefs.edit().putString("host", host).apply();
        showSplash("Cargando…");
        web.loadUrl("https://" + host + path);
    }

    private void onMainFrameFailed() {
        if (resolving || pageFailed) return;
        pageFailed = true;
        if (++switches > 3) { showError("No se pudo cargar Videx.\nInténtalo de nuevo en unos minutos."); return; }
        final String bad = currentHost;
        final String path = currentPath();
        showSplash("Cambiando de servidor…");
        findHost(bad, host -> {
            if (host != null) load(host, path);
            else showError(online()
                    ? "No se pudo conectar con ningún servidor de Videx.\nInténtalo de nuevo en unos minutos."
                    : "Sin conexión a internet.\nRevisa tu red e inténtalo de nuevo.");
        });
    }

    /** Busca (en segundo plano) un dominio que responda. Primero el último usado; si falla, prueba el resto a la vez. */
    private void findHost(final String skip, final HostCb cb) {
        resolving = true;
        final String saved = prefs.getString("host", null);
        new Thread(() -> {
            String winner = null;
            boolean triedSaved = saved != null && isKnown(saved) && !saved.equals(skip);
            if (triedSaved && probe(saved, 3500)) winner = saved;
            if (winner == null) {
                List<String> rest = new ArrayList<>();
                for (String d : DOMAINS) {
                    if (d.equals(skip)) continue;
                    if (triedSaved && d.equals(saved)) continue;
                    rest.add(d);
                }
                winner = race(rest, 4000);
            }
            final String w = winner;
            ui.post(() -> {
                resolving = false;
                if (isFinishing() || isDestroyed()) return;
                cb.on(w);
            });
        }).start();
    }

    private String race(List<String> hosts, final int timeoutMs) {
        if (hosts.isEmpty()) return null;
        final Object lock = new Object();
        final String[] winner = {null};
        final int[] pending = {hosts.size()};
        for (final String h : hosts) {
            new Thread(() -> {
                boolean ok = probe(h, timeoutMs);
                synchronized (lock) {
                    if (ok && winner[0] == null) winner[0] = h;
                    pending[0]--;
                    lock.notifyAll();
                }
            }).start();
        }
        synchronized (lock) {
            long end = System.currentTimeMillis() + timeoutMs + 1500;
            while (winner[0] == null && pending[0] > 0) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) break;
                try { lock.wait(left); } catch (InterruptedException e) { break; }
            }
            return winner[0];
        }
    }

    private boolean probe(String host, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://" + host + PROBE_PATH).openConnection();
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", ua);
            c.setRequestProperty("Accept", "application/manifest+json,application/json,*/*");
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            byte[] buf = new byte[1024];
            int n = in.read(buf);
            in.close();
            return n > 0 && new String(buf, 0, n, "UTF-8").contains(PROBE_MARK);
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ---------------------------------------------------------------- enlaces

    /** true = ya lo gestionamos nosotros (no cargar en el WebView). */
    private boolean handleUrl(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        if (scheme.equals("http") || scheme.equals("https")) {
            if (isVidexHost(u.getHost())) return false;
            openExternal(new Intent(Intent.ACTION_VIEW, u));
            return true;
        }
        if (scheme.equals("about") || scheme.equals("blob") || scheme.equals("data") || scheme.equals("javascript")) return false;
        try {
            Intent i = scheme.equals("intent")
                    ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, u);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            i.setComponent(null);
            i.setSelector(null);
            openExternal(i);
        } catch (Exception ignored) {}
        return true;
    }

    private void openExternal(Intent i) {
        try { startActivity(i); } catch (ActivityNotFoundException ignored) {}
    }
}
